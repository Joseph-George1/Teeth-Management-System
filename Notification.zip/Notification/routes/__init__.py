"""Notification API routes"""
